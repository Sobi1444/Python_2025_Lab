# wielomian gesty oparty na liscie wspolczynnikow
# indeks listy = potega x, np. [3, 0, 2] to 3 + 0x + 2x^2
# wspolczynniki moga byc int lub float

class Poly:

    #konstruktor klasy Poly
    #self - referencja do aktualnego obiektu na ktorym wywolywana jest metoda
    def __init__(self, wspolczynniki=None):
        # wspolczynniki[i] to wspolczynnik przy x^i
        if wspolczynniki is None:
            self.wspolczynniki = [0]
        else:
            self.wspolczynniki = list(wspolczynniki)

        self._usun_zera()

    # usuwa zbedne zera z konca listy (poza indeksem 0) np. [1,2,0,0] -> [1,2]
    def _usun_zera(self):
        #[-1] <- ostatni element np w [1,2,0,3] to 3
        while len(self.wspolczynniki) > 1 and self.wspolczynniki[-1] == 0:
            self.wspolczynniki.pop()

    #zwraca stopien wielomianu -> dlugosc listy minus 1 np. dla [1,2,3] stopien to 2 bo x^2
    def stopien(self):
        return len(self.wspolczynniki) - 1

    #sprawdzenie czy wielomian
    def jest_zerowy(self):
        return self.wspolczynniki == [0]

    # zwraca wspolczynnik przy x^n
    def __getitem__(self, n):
        if n < 0 or n >= len(self.wspolczynniki):
            return 0
        return self.wspolczynniki[n]

    #uruchamia sie gdy sprawdzane jest wielomian1 == wielomian2
    def __eq__(self, other):
        # wielomiany rowne gdy ich roznica jest wielomianem zerowym
        return (self - other).jest_zerowy()

    # != porownuje czy to ten sam obiekt w pamieci, teraz sprawdza czy wielomiany maja te same wartosci przy potegach
    def __ne__(self, other):
        return not self == other

    #dodawanie a+b, dodaje wspolczynniki pozycja po pozycji [1,2]+[3,4]=[4,6]
    def __add__(self, other):

        #jezeli wielomian+stala, to zmiana stalej w wielomian
        if isinstance(other, (int, float)):
            other = Poly([other])

        n = max(len(self.wspolczynniki), len(other.wspolczynniki))
        wynik = []
        for i in range(n):
            wynik.append(self[i] + other[i])
        return Poly(wynik)

    # odwrotna kolejnosc stala + wielomian
    def __radd__(self, other):
        return self.__add__(other)

    #odejmowanie a-b, zachowanie to samo co w add
    def __sub__(self, other):

        if isinstance(other, (int, float)):
            other = Poly([other])

        n = max(len(self.wspolczynniki), len(other.wspolczynniki))
        wynik = []
        for i in range(n):
            #dodanie na koniec listy wynik
            wynik.append(self[i] - other[i])
        return Poly(wynik)
    #odwrotna kolejnosc
    def __rsub__(self, other):
        if isinstance(other, (int, float)):
            other = Poly([other])
        return other.__sub__(self)

    """mnozenie a*b, robi podwojna petle kazdy wyraz z a mnozy sie 
    przez kazdy b i wrzuca w odpowiednie miejsce w wyniku"""
    def __mul__(self, other):

        if isinstance(other, (int, float)):
            other = Poly([other])

        # stopien wyniku to suma stopni -> (x^2)*(x^3)=x^5 -> +1 (bo len-1) daje 5
        n = self.stopien() + other.stopien() + 1
        wynik = [0] * n # --> [0]*3 = [0,0,0]
        # i - potega, a - wspolczynnik z pierwszego wielomianu
        for i, a in enumerate(self.wspolczynniki):
            #j-potega, b-wspolczynnik z drugiego wielomianu
            for j, b in enumerate(other.wspolczynniki):
                wynik[i + j] += a * b
        return Poly(wynik)
    #odwrotna kolejnosc
    def __rmul__(self, other):
        return self.__mul__(other)

    def __call__(self, x):
        # obliczanie wartosci algorytmem Hornera
        # zamiast liczyc kazda potege osobno, zaczyna od najwyzszego wspolczynnika
        # p(x) = a0 + x*(a1 + x*(a2 + ... + x*an))
        wynik = 0
        for wspolczynnik in reversed(self.wspolczynniki):
            wynik = wynik * x + wspolczynnik
        return wynik

    # zamienia Poly([3,5,2]) na 3 + 5x + 2x^2
    def __str__(self):
        if self.jest_zerowy():
            return "0"

        wyrazy = []
        # range(start, stop, krok)
        for i in range(self.stopien(), -1, -1):
            wspolczynnik = self.wspolczynniki[i]
            if wspolczynnik == 0:
                continue
            if i == 0:
                wyrazy.append(str(wspolczynnik))
            elif i == 1:
                wyrazy.append(f"{wspolczynnik}x")
            else:
                wyrazy.append(f"{wspolczynnik}x^{i}")
        #np wyrazy = ["2x^2", "5x", "-3"] -> " + ".join(wyrazy) -> 2x^2 + 5x + -3, replace naprawia
        return " + ".join(wyrazy).replace("+ -", "- ")

    #do debugowania, sprawdzenie jak wyglada Poly([tablica])
    def __repr__(self):
        return f"Poly({self.wspolczynniki})"
