from poly import Poly

# testy
def test_dodawanie():
    a = Poly([1, 2, 3])  # 1 + 2x + 3x^2
    b = Poly([4, 5])  # 4 + 5x
    c = a + b
    assert c.wspolczynniki == [5, 7, 3], f"blad: {c.wspolczynniki}"
    print("dodawanie: OK")

def test_odejmowanie():
    a = Poly([5, 7, 3])
    b = Poly([1, 2, 3])
    c = a - b
    assert c.wspolczynniki == [4, 5], f"blad: {c.wspolczynniki}"
    print("odejmowanie: OK")

def test_mnozenie():
    a = Poly([1, 1])  # 1 + x
    b = Poly([1, 1])  # 1 + x
    c = a * b  # powinno byc 1 + 2x + x^2
    assert c.wspolczynniki == [1, 2, 1], f"blad: {c.wspolczynniki}"
    print("mnozenie: OK")

def test_horner():
    p = Poly([1, 2, 3])  # 1 + 2x + 3x^2
    assert p(0) == 1
    assert p(1) == 6  # 1 + 2 + 3
    assert p(2) == 17  # 1 + 4 + 12
    print("Horner: OK")

def test_rownosc():
    a = Poly([1, 2, 3])
    b = Poly([1, 2, 3])
    c = Poly([1, 2, 4])
    assert a == b
    assert a != c
    print("rownosc: OK")

def test_indeksowanie():
    p = Poly([5, 0, 3])  # 5 + 0x + 3x^2
    assert p[0] == 5
    assert p[1] == 0
    assert p[2] == 3
    assert p[5] == 0  # poza zakresem zwraca 0
    print("indeksowanie: OK")

def test_stopien():
    p = Poly([1, 2, 3])
    assert p.stopien() == 2
    p2 = Poly([0])
    assert p2.stopien() == 0
    print("stopien: OK")

def test_usun_zera():
    # wiodace zera powinny byc usuwane
    p = Poly([1, 2, 0, 0])
    assert p.stopien() == 1
    print("usuwanie zer: OK")

def test_wielomian_zerowy():
    a = Poly([1, 2, 3])
    b = Poly([1, 2, 3])
    roznica = a - b
    assert roznica.jest_zerowy()
    print("wielomian zerowy: OK")

def uruchom_testy():
    print("--- uruchomienie testow ---")
    test_dodawanie()
    test_odejmowanie()
    test_mnozenie()
    test_horner()
    test_rownosc()
    test_indeksowanie()
    test_stopien()
    test_usun_zera()
    test_wielomian_zerowy()
    print("--- wszystkie testy OK ---")


# menu
def wczytaj_wspolczynniki():
    print("podaj wspolczynniki oddzielone spacjami (od najnizszej potegi):")
    print("np. '1 2 3' oznacza 1 + 2x + 3x^2")
    dane = input("> ").split()
    return Poly([float(x) for x in dane])

def wyswietl_menu():
    print()
    print("=== Wielomiany ===")
    print("1. wczytaj wielomian A")
    print("2. wczytaj wielomian B")
    print("3. wyswietl A i B")
    print("4. A + B")
    print("5. A - B")
    print("6. A * B")
    print("7. oblicz wartosc A(x)")
    print("8. porownaj A == B")
    print("9. wspolczynnik A[n]")
    print("10. uruchom testy")
    print("0. wyjdz")
    print("> ", end="")

def main():
    A = Poly([0])
    B = Poly([0])

    print("DEBUG: A =", A)
    print("DEBUG: B =", B)

    while True:
        wyswietl_menu()
        wybor = input()

        if wybor == "0":
            break
        elif wybor == "1":
            A = wczytaj_wspolczynniki()
            print(f"A = {A}")
        elif wybor == "2":
            B = wczytaj_wspolczynniki()
            print(f"B = {B}")
        elif wybor == "3":
            print(f"A = {A}")
            print(f"B = {B}")
        elif wybor == "4":
            print(f"A + B = {A + B}")
        elif wybor == "5":
            print(f"A - B = {A - B}")
        elif wybor == "6":
            print(f"A * B = {A * B}")
        elif wybor == "7":
            x = float(input("x = "))
            print(f"A({x}) = {A(x)}")
        elif wybor == "8":
            if A == B:
                print("A == B")
            else:
                print("A != B")
        elif wybor == "9":
            n = int(input("n = "))
            print(f"A[{n}] = {A[n]}")
        elif wybor == "10":
            uruchom_testy()
        else:
            print("nieznana opcja")

if __name__ == "__main__":
    main()
